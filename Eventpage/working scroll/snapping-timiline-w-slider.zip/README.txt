A Pen created at CodePen.io. You can find this one at https://codepen.io/PawleyBoboli/pen/QpGKjr.

 An image timeline that is size-responsive and snaps to center imag containers when the slider is released.